/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "src/trace_redaction/trace_redaction_framework.h"

namespace perfetto::trace_redaction {

CollectPrimitive::~CollectPrimitive() = default;

base::Status CollectPrimitive::Begin(Context*) const {
  return base::OkStatus();
}

base::Status CollectPrimitive::End(Context*) const {
  return base::OkStatus();
}

BuildPrimitive::~BuildPrimitive() = default;

TransformPrimitive::~TransformPrimitive() = default;

}  // namespace perfetto::trace_redaction
